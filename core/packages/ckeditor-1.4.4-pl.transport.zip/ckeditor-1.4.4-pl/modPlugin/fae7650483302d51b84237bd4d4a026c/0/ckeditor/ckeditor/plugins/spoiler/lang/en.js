﻿CKEDITOR.plugins.setLang( 'spoiler', 'en', {
	toolbar: 'Spoiler'
} );
