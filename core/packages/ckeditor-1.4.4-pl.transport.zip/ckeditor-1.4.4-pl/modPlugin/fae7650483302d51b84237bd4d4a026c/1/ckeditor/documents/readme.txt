Extra: CKEditor
Version: 1.4.4
Created: 2023.03.11
Since: 2012.12.5
Updated: Dmitry Kasatkin (dimasites@yandex.com)
Author: Danil Kostin
License: GNU GPLv2 (or later at your option)

Integrates CKEditor WYSYWYG Editor into MODX2 and MODX3
Just install it and its ready to use! Try to edit any resource and have fun!
