<?php

require_once(dirname(__FILE__, 2) . '/msorder.class.php');

class msOrder_mysql extends msOrder
{
}
