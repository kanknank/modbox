<?php

require_once(dirname(__FILE__, 2) . '/mslink.class.php');

class msLink_mysql extends msLink
{
}
