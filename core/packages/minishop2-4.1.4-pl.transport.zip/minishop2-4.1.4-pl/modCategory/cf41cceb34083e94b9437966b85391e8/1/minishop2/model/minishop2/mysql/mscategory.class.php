<?php

require_once(dirname(__FILE__, 2) . '/mscategory.class.php');

class msCategory_mysql extends msCategory
{
}
