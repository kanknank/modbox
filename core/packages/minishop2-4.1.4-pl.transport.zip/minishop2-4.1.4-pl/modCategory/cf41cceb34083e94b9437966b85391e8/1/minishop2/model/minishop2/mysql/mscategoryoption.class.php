<?php

require_once(dirname(__FILE__, 2) . '/mscategoryoption.class.php');

class msCategoryOption_mysql extends msCategoryOption
{
}
