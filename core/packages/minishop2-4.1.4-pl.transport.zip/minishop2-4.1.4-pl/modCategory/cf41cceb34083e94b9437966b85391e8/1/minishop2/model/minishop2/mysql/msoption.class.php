<?php

require_once(dirname(__FILE__, 2) . '/msoption.class.php');

class msOption_mysql extends msOption
{
}
