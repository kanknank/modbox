<?php

require_once(dirname(__FILE__, 2) . '/msproductlink.class.php');

class msProductLink_mysql extends msProductLink
{
}
