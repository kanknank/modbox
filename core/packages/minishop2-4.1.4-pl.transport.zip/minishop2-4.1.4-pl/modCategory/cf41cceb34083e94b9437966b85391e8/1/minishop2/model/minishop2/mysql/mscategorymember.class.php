<?php

require_once(dirname(__FILE__, 2) . '/mscategorymember.class.php');

class msCategoryMember_mysql extends msCategoryMember
{
}
