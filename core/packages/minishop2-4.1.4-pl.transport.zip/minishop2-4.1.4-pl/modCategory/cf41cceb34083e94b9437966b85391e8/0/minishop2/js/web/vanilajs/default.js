import MiniShop from './modules/minishop.class.js'

if (miniShop2Config) {
  window.miniShop2 = new MiniShop(miniShop2Config)
}
