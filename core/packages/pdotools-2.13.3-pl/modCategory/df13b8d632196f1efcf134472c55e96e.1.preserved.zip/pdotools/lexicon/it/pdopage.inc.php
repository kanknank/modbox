<?php
/**
 * pdoPage Italian Lexicon Entries for pdoPage
 *
 * @package pdotools
 * @subpackage lexicon
 * @language it
 */
$_lang['pdopage_first'] = 'Prima';
$_lang['pdopage_last'] = 'Ultima';
$_lang['pdopage_more'] = 'Scarica di più';
$_lang['pdopage_page'] = 'Pagina';
$_lang['pdopage_from'] = 'di';
