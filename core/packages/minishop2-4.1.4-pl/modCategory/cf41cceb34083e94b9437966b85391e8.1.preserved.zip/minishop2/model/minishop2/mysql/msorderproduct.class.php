<?php

require_once(dirname(__FILE__, 2) . '/msorderproduct.class.php');

class msOrderProduct_mysql extends msOrderProduct
{
}
