<?php

require_once(dirname(__FILE__, 2) . '/msproductdata.class.php');

class msProductData_mysql extends msProductData
{
}
