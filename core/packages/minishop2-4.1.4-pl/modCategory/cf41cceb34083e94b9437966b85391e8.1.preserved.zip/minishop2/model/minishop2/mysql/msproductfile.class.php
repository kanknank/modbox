<?php

require_once(dirname(__FILE__, 2) . '/msproductfile.class.php');

class msProductFile_mysql extends msProductFile
{
}
