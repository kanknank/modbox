<?php

class msProductGetProcessor extends modObjectGetProcessor
{
    public $classKey = 'msProduct';
    public $languageTopics = ['minishop2:default'];
}

return 'msProductGetProcessor';
