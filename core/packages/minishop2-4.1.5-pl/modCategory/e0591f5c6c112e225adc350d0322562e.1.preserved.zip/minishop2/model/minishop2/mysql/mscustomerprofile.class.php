<?php

require_once(dirname(__FILE__, 2) . '/mscustomerprofile.class.php');

class msCustomerProfile_mysql extends msCustomerProfile
{
}
