<?php

require_once(dirname(__FILE__, 2) . '/msproduct.class.php');

class msProduct_mysql extends msProduct
{
}
