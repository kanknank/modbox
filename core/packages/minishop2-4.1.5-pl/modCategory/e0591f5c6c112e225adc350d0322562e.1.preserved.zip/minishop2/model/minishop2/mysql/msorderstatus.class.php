<?php

require_once(dirname(__FILE__, 2) . '/msorderstatus.class.php');

class msOrderStatus_mysql extends msOrderStatus
{
}
