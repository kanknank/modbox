<?php

require_once(dirname(__FILE__, 2) . '/msproductoption.class.php');

class msProductOption_mysql extends msProductOption
{
}
