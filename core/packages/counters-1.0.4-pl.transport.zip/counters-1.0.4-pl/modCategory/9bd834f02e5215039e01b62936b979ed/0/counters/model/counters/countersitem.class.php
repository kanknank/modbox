<?php

/**
 * @package counters
 */
class CountersItem extends xPDOSimpleObject
{
}