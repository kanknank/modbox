<?php

$_lang['counters_prop_limit'] = 'Ограничение вывода Счетчиков на странице.';
$_lang['counters_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['counters_prop_sortby'] = 'Поле сортировки.';
$_lang['counters_prop_sortdir'] = 'Направление сортировки.';
$_lang['counters_prop_tpl'] = 'Чанк оформления каждого ряда Счетчиков.';
$_lang['counters_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
