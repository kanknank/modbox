<?php
require_once (dirname(__DIR__) . '/countersitem.class.php');
class CountersItem_mysql extends CountersItem {}