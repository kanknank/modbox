--------------------
Counters
--------------------
Author: Aleksandr Huz <Superboshnik@gmail.com>
--------------------