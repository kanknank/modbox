phpThumbOn
=========
Оптимизированный сниппет phpThumbOf под MODX Revolution. Схожый синтаксис, но более быстрая работа. Более подробно смотрите в changelog

Проект на GitHub: https://github.com/AgelxNash/phpthumbon
Документация: http://blog.agel-nash.ru/addon/phpthumbon.html