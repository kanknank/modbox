<?php

require_once(dirname(__FILE__, 2) . '/mspayment.class.php');

class msPayment_mysql extends msPayment
{
}
